﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace maddweb.Models
{
	public class FileUploadResult
	{

		public string Name { get; set; }

		public long Length { get; set; }
	}
}
