﻿insert into Entry 
values (1, 36.5, 'aa', '2020-04-25');